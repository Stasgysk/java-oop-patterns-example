public enum Event {
    LIGHTS_ON,
    WINDOW_OPENED,
    DOOR_OPENED
}
