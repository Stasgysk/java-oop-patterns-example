public class Level {

    public void initialize() {
        System.out.println("Creating level...");
    }
}
