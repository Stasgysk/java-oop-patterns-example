public interface Skin {

    void draw();
}
