public interface MultiChatFactory {

    Connection createConnection();
    Skin createSkin();
}
