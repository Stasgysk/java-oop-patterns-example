public class MessengerSkin implements Skin {

    @Override
    public void draw() {
        System.out.println("Draw blue skin for Messenger.");
    }
}
