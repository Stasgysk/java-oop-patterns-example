public class Passat extends Car {
}
