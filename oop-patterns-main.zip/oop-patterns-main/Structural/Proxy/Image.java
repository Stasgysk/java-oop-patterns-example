public interface Image {

    void displayImage();
}
