public interface Meal {

    double getPrice();
    void printMeal();
}
