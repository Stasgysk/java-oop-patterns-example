public class Princess {

    public void marry() {
        System.out.println("You have married the princess.");
    }
}
