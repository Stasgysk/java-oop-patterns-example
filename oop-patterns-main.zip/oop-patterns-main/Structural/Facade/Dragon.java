public class Dragon {

    public void kill() {
        System.out.println("Dragon is killed.");
    }
}
