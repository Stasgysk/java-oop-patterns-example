public class Player {

    public void wander() {
        System.out.println("Wander through the dark forest.");
    }
}
