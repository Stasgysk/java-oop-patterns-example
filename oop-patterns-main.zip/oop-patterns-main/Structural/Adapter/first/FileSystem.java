package first;

public class FileSystem {

    public String getFile(String fileName) {
        return "Content of file " + fileName;
    }
}
