package first;

public interface DocumentAdapter {

    Document getDocument(String name);
}
