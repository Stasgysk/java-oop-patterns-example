package first;

public class Database {

    public String processQuery(String query) {
        return "Content of query " + query;
    }
}
